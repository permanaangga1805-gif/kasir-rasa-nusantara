# Kasir Rasa Nusantara

Aplikasi kasir multi-cabang. Frontend: React + Vite. Backend: Supabase.

---

## 1. Jalankan di komputer sendiri (opsional, buat cek dulu)

```bash
npm install
cp .env.example .env
# lalu edit .env, isi VITE_SUPABASE_ANON_KEY dengan Publishable key asli dari Supabase
npm run dev
```

Buka `http://localhost:5173`.

---

## 2. Deploy ke internet (gratis) — pakai Vercel + GitHub

Ini cara yang direkomendasikan, karena setiap kali kamu update kode dan push ke
GitHub, Vercel otomatis build & deploy ulang tanpa kamu upload manual lagi.

### Langkah A — Push project ini ke GitHub

1. Buat akun di https://github.com kalau belum punya
2. Buat repository baru (klik "New repository"), kasih nama misalnya
   `kasir-rasa-nusantara`, biarkan **Private** kalau tidak mau kode terlihat
   publik, JANGAN centang "Add README" (kita sudah punya)
3. Di komputer kamu, masuk ke folder project ini lewat terminal, lalu:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME_KAMU/kasir-rasa-nusantara.git
git push -u origin main
```

(Ganti `USERNAME_KAMU` sesuai akun GitHub kamu. File `.env` TIDAK akan ikut
ter-push karena sudah ada di `.gitignore` — aman, kunci Supabase kamu tidak
bocor ke GitHub.)

### Langkah B — Sambungkan ke Vercel

1. Buat akun di https://vercel.com (bisa langsung pakai akun GitHub kamu)
2. Klik **"Add New" → "Project"**
3. Pilih repository `kasir-rasa-nusantara` yang barusan kamu push
4. Vercel otomatis mendeteksi ini project Vite — biarkan pengaturan default
   (Build Command: `vite build`, Output Directory: `dist`)
5. **PENTING — sebelum klik Deploy**, buka bagian **"Environment Variables"**,
   tambahkan 2 baris ini:

   | Name | Value |
   |---|---|
   | `VITE_SUPABASE_URL` | `https://smemgdqmfvgccipdinox.supabase.co` |
   | `VITE_SUPABASE_ANON_KEY` | *(Publishable key dari Supabase → Project Settings → Data API)* |

6. Klik **Deploy**, tunggu 1-2 menit
7. Selesai — kamu dapat link seperti `https://kasir-rasa-nusantara.vercel.app`

Setiap kali kamu (atau saya) mengedit kode lagi, tinggal:
```bash
git add .
git commit -m "update fitur X"
git push
```
Vercel otomatis build & deploy ulang dalam 1-2 menit.

---

## 3. Alternatif — Netlify Drop (paling cepat, TANPA git/GitHub)

Cocok buat coba-coba cepat atau kalau belum familiar dengan git:

```bash
npm install
cp .env.example .env   # isi dengan kunci asli
npm run build
```

Ini akan menghasilkan folder `dist/`. Buka https://app.netlify.com/drop di
browser, lalu **drag & drop folder `dist` itu** ke halaman tersebut. Netlify
langsung kasih link publik dalam beberapa detik.

⚠️ Kekurangan cara ini: env var (`VITE_SUPABASE_ANON_KEY`) ter-bake langsung
ke dalam file build saat itu juga (bukan disimpan sebagai secret terpisah).
Ini tetap aman KARENA kunci "anon/publishable" memang didesain untuk boleh
terlihat publik (keamanan sungguhan ada di RLS Supabase, bukan di kunci ini).
Tapi setiap kamu update kode, kamu harus build & drag-drop ulang manual — beda
dengan cara Vercel+GitHub yang otomatis.

---

## 4. Checklist setelah online

- [ ] Coba login pakai akun `super_admin` yang sudah ada
- [ ] Coba daftar akun baru lewat tombol "Daftar Akun", cek muncul di tab
      **User → Menunggu Aktivasi**
- [ ] Aktifkan akun tsb, assign ke salah satu cabang, coba login pakai akun itu
- [ ] Buka Supabase Dashboard → Authentication → URL Configuration → pastikan
      **Site URL** diisi dengan domain Vercel kamu (mis.
      `https://kasir-rasa-nusantara.vercel.app`) — ini dipakai Supabase untuk
      link di email (reset password, dsb), bukan untuk login biasa jadi tidak
      wajib banget di awal, tapi baiknya diisi
- [ ] Tes checkout (bayar tunai & QRIS) dari 2 device berbeda untuk pastikan
      stok & riwayat sinkron real-time

---

## Struktur project

```
├── index.html
├── package.json
├── vite.config.js
├── .env.example        ← salin jadi .env untuk lokal, isi kunci asli
└── src/
    ├── main.jsx         ← entry point
    ├── supabaseClient.js
    └── KasirApp.jsx     ← seluruh aplikasi (satu file besar)
```

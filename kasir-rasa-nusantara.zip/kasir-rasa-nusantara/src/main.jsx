import React from 'react';
import ReactDOM from 'react-dom/client';
import KasirApp from './KasirApp.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <KasirApp />
  </React.StrictMode>
);

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  // Ini akan muncul di console browser kalau env var belum di-set dengan
  // benar di Vercel/Netlify (lihat README.md bagian "Deploy").
  console.error(
    'VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY belum di-set. ' +
    'Cek Environment Variables di dashboard Vercel/Netlify kamu.'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
